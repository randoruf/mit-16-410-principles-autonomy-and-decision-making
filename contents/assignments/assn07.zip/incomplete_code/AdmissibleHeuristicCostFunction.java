package team16410;

/**
 * This class implements an admissible heuristic cost function. An
 * admissible heuristic cost function computes the cost based on the
 * total path length and the cost to go, i.e. f = g + h.
 * 
 */


public class AdmissibleHeuristicCostFunction extends HeuristicCostFunction
{
    public AdmissibleHeuristicCostFunction(State g) 
	throws NotApplicableException{
	super(g);
    }

    /**
     * Returns the cost of a new path N', which is an extension of a
     * path N to vertex v. The cost is computed as follows:
     * f(N') = g(N') + h(N') 
     * @param	node		Search node that we are evaluating
     * @return		Estimated cost of complete path that extends 
     *                   <code>node</code> to the goal
     * @throws NotApplicatbleException  if node.State is not of type 
     *         <code>RobotState</code>
     */
    public double getCost(Node node) throws NotApplicableException {
	///*** You fill in here***///
    }
}
