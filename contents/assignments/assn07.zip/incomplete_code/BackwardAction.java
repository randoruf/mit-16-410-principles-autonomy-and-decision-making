package team16410;
import battlecode.common.*;


public final class BackwardAction extends Action{
    
    RobotController rc;
    BackwardAction(RobotState _pre,RobotController _rc,double _cost){
	super(_pre, new RobotState(_pre.getRP(),_pre.getLocation().subtract(_pre.getDirection()),_pre.getDirection()),
	      "move backward",_cost);
	rc = _rc;
    }
    public void doAction() throws GameActionException{
	rc.moveBackward();
    }
}