package team16410;



import java.util.Queue;
import java.util.HashSet;
//import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * This class defines an object that can perform best-first search.
 * The true costs are provided as part of the problem (i.e. in the actions
 * and/or states).  However, the search proceeds in the order defined in
 * the CostFunction object.
 * 
 */

public class BestFirstSearch {
    /**
     * the search queue: unexpanded leaves of the search tree,
     * prioritized by their cost (as defined by costfunction)
     **/
    protected PriorityQueue<PriorityQueueItem<Node>> m_Q;

    /**
     * CostFunction is a function that assigns a search node the
     * cost by which we order the best-first search... Well actually,
     * it's an object that promisses to have a method that does that.
     **/
    protected CostFunction costfunction;

    /**
     * the set of states already expanded by the search.
     * they need not ever be expanded a second time
     **/
    protected Set<State> m_expandedVertices;

    /**
     * the goal state of the search.  This is a class variable to allow
     * for incremental searching
     */
    protected State goal;

    // for analysis
    protected int m_maximumQueueSize;
    protected Set<State> m_visitedVertices;

    /**
     * @param f  The function that defines the "best" that orders the search
     * returns  An object that is ready to perform best-first search.
     **/
    public BestFirstSearch(CostFunction f)
    {
	this.costfunction = f;
	m_Q = new PriorityQueue<PriorityQueueItem<Node>>();
	m_expandedVertices = new HashSet<State>();
	m_visitedVertices = new HashSet<State>(); 
    }
	
	
    /**
     * This method returns the maximum queue size reached during the
     * search.
     * 
     * @return			Maximum queue size reached.
     */
    public int getMaximumQueueSize()
    {
	return m_maximumQueueSize;
    }
	
    /**
     * This method returns the number of paths that were extended
     * during the search.
     * 
     * @return			Number of paths extended.
     */
    public int getExtendedPathsCount()
    {
	return (m_expandedVertices.size());
    }
	
    /**
     * This method returns the number of vertices that were visited
     * during the search.
     * 
     * @return			Number of visited vertices.
     */
    public int getVisitedVerticesCount(){
	return (m_visitedVertices.size());
    }
	
    /**
     * Find all children of <code>node</code> and create 
     * a new search node for each one
     * 
     * @param node		search node to be extended.
     * @return			Set of new search nodes.
     */
    protected Set<Node> getChildren(Node node)	{
	Set<Node> children = new HashSet<Node>();
	State state = node.getState();
	// Find all children vertices of N.
	for (Action a : state.actionsAvailable()){
	    // generate a new search node
	    Node newNode = new Node(node,a);
	    children.add(newNode);				
	    // Add the child node to Visited (not Expanded)
	    m_visitedVertices.add(newNode.getState());
	}	
	return children;
    }

    /**
     * Add the children of the current node to the search queue with 
     * correct priorities
     * @param node   The node whose children are to be added.
     **/  
    protected void updateQueue(Node node){
	for (Node n : getChildren(node)){
		try{
			m_Q.add(new PriorityQueueItem<Node>(n,costfunction.getCost(n)));
		}catch (CostFunction.NotApplicableException e){
			System.out.println(e);
		}
	}	
	}
    /**
     * This method performs a general best-first graph search.
     * This method keeps track of:
     * <ul>
     *  <li>1. Number of extended paths</li>
     *  <li>2. Expanded States list</li>
     *  <li>3. Maximum queue size reached during the search</li>
     *  </ul>
     * @param S			Index of the start vertex.
     * @param G			Index of the goal vertex.
     * @return			Returns a sequence of actions that will take 
     *                   us from the S to G if it exists, otherwise
     * 			 an empty list is returned. 
     **/
    public LinkedList<Action> search(State S, State G)
    {
	LinkedList<Action> plan = initializeSearch(S,G);
	while (plan==null){	    
	    plan = incrementSearch(10000);
	}
	return plan;
    }

    public LinkedList<Action> initializeSearch(State S, State G){
	this.goal = G;
		
	// Clear the search queue.
	m_Q.clear();
	// Reset the maximum size of the queue size.
	m_maximumQueueSize = 0;
	// Reset the number of extended paths.
	//m_extendedPathsCount = 0;
	// Clear the set of visited vertices.
	m_visitedVertices.clear();	
	//=============================================================
	// Initialize Q with partial path (S) as only entry; set
	// Expanded = ().
	//=============================================================	
	m_Q.add(new PriorityQueueItem<Node>(new Node(S),0.0));
	// Clear the set of expanded vertices.
	m_expandedVertices.clear();		
	// Add the start vertex to the set of visited vertices.
	m_visitedVertices.add(S);
	// Update the maximum queue size reached.
	if (m_Q.size() > m_maximumQueueSize){
		m_maximumQueueSize = m_Q.size();
	}
	return null;
    }
    
    /**
     * incrementSearch expects that the search already has been initialized
     * @param countdown  the number of queue elements to pop before 
     *             halting
     * @return a sequence of actions (a plan) that achieves the goal
     *          or an empty list if one does not exist
     *          or null if time expires.
     **/
    public LinkedList<Action> incrementSearch(int countdown){
	// While Q is not empty,
	while (!m_Q.isEmpty() && countdown > 0){
	    countdown--;
	    // Pick the partial path N with lowest total cost f(N) in Q.
		// HINT: Node that the getState of the Node class method gives you head(N).
	    ///*** You fill in here ***///
		
		
	    //if we have found the goal ,
		// return the plan that reaches it
		// HINT: 1. Note that the goal state is variable of this calss
		//       2. You can just use listifyActions method of the Node class 		
		//             to get the plan corresponding to that node.
	        ///*** You fill in here ***///
		
		
	    // Otherwise{
			// if the current node is a state we have not yet expanded,
		    // add it to the expanded set and add it's children to
		    // the queue
			// HINT: 1. Note that m_expandedVertices is a set of expanded states.
			//		 2. To update the queue, you can just use the UpdateQueue method 
		    //             of this class.
	            ///*** You fill in here ***///
		    
		
		
		    // Update the number of maximum queue size reached
		    // during the search.
		    if (m_Q.size() > m_maximumQueueSize){
			m_maximumQueueSize = m_Q.size();
		    }
		//}
	    
	}
	// we failed to find a plan
	if (m_Q.isEmpty())
	    // the tree is exhausted, there is no solution
	    return new LinkedList<Action>();
	// the search is incomplete
	else return null;
    }
}
