package team16410;
import battlecode.common.*;
/**
 * This interface defines the costs to be used in Problem Set 3
 *
 * @author Tom Temple, Sertac Karaman
 **/

public final class Constants{
    public static final double TURN_COST_RATE = 0.1;
    public static final double MIN_MOVE_COST = 1.0;
    public static final double TERRAIN_WEIGHT = 0.25;

    /**
     * The cost of a turn from direction d1 to direction d2 is:
     * TURN_COST_RATE*Math.abs(d1.ordinal()-d2.ordinal())
     */
    public static double turnCost(Direction d1, Direction d2){
	return (Constants.TURN_COST_RATE*Math.abs(d1.ordinal()-d2.ordinal()));
    }

    /**
     * The cost of a forward move onto a location l is:
     * MIN_MOVE_COST + l.height*TERRAIN_WEIGHT
     */
    public static double forwardCost(int height){
	return (Constants.MIN_MOVE_COST + 
		(height*Constants.TERRAIN_WEIGHT));
    }
}