package team16410;
/**
 * This is an interface for a cost function used within an informed
 * search method.
 * 
 */

public interface CostFunction
{
	/**
	 * Returns the (prioritization) cost of a search node
	 * 
	 * @param	node		Node of the search tree to expand.
	 * @return			the cost that should be used to
	 *                        prioritize this node in our search.
	 *                        This need not be related with the _true_
	 *                        cost of this node.
	 * @throws NotApplicableException if this cost function cannot be
	 *         applied to this argument.
	 */
    public double getCost(Node node) throws NotApplicableException;

    class NotApplicableException extends Exception{
	NotApplicableException(String message) {
	    super(message);
	}
    }	
}
