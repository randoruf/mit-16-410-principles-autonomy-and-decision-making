package team16410;
import battlecode.common.*;

/**
 * This class provides the doAction that will move the robot forward by
 * one unit
 **/
public final class ForwardAction extends Action{
    RobotController rc;
    ForwardAction(RobotState _pre,RobotController _rc,double _cost){
	super(_pre, new RobotState(_pre.getRP(),
				   _pre.getLocation().add(_pre.getDirection()),
				   _pre.getDirection()),
	      "move forward",_cost);
	rc = _rc;
    }

    /**
     * Move robot forward one unit
     * @throws GameActionException if the move is illegal
     **/
    public void doAction() throws GameActionException{
	rc.moveForward();
    }
}
	      