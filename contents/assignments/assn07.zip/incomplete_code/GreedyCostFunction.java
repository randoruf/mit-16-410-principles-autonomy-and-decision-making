package team16410;


/**
 * This class implements a greedy cost function. A greedy cost function
 * computes the cost based only on the estimated cost to go, i.e.
 * f = h.
 * 
 */
public class GreedyCostFunction extends HeuristicCostFunction
{
    public GreedyCostFunction(State g) throws NotApplicableException{
	super(g);
    }
    /**
     * Returns the cost of a new Node N, 
     * The cost is computed as follows:
     * f(N) = h(N)).
     * 
     * @param	node		Search node we wish to add
     * @return		Cost with which this node should be prioritized
     */
    public double getCost(Node node) throws NotApplicableException{
	///*** You fill in here ***///
    }

}
