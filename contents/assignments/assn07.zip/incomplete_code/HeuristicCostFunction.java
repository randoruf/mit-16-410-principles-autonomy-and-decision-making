package team16410;
import battlecode.common.*;

/**
 * A heuristic cost function is a class that implements cost function
 * and provides a heuristic estimate of the cost to reach the goal from
 * a given state.
 * Once again Java makes you write several new files for something trivial.  
 * Even <emph>Matlab</emph> suports closures and function passing.
 **/
public abstract class HeuristicCostFunction implements CostFunction{
    
    /**
     * the goal state of the search
     */
    protected RobotState goal;
    
    /**
     * Construct a new heuristic function for the given goal;
     */
    public HeuristicCostFunction(State _goal) throws NotApplicableException   {
	if (!(_goal instanceof RobotState))
	    throw new NotApplicableException("goal state must be a Robot State");
	this.goal = (RobotState)_goal;
    }
    
    /**
     * the implementation of getCost is still left to subclasses to define
     * see CostFunction for the spec for getCost
     **/
    public abstract double getCost(Node node) throws NotApplicableException;


    /**
     * This heuristic is an object method that basically creates a closure
     * deffun object.heuristic = lambda(S: return class.heuristic(S,goal))
     * The only interesting part is the cast.
     *
     * @param S   The state whose heuristic we would like to evaluate
     * @return an estimate of the cost to go from S to the goal state.
     * @throws NotApplicableException  if S is not a RobotState
     **/
    protected double heuristic(State S) throws NotApplicableException{
	if (!(S instanceof RobotState))
	    throw new NotApplicableException("start state must be a Robot State");
	return heuristic((RobotState) S,goal);
    }

    /**
     * @param S    Start state
     * @param G    Goal state
     * @return an estimate of the cost to go from S to G
     **/
    private static double heuristic(RobotState S,RobotState G){
	int sx = S.getLocation().getX();
	int sy = S.getLocation().getY();
	int sd = S.getDirection().ordinal();
	int gx = G.getLocation().getX();
	int gy = G.getLocation().getY();
	int gd = G.getDirection().ordinal();
	double turncost = Constants.TURN_COST_RATE*
	    Math.abs(sd-gd);
	return (Constants.MIN_MOVE_COST*(Math.abs(sx-gx)+
					 Math.abs(sy-gy)) +
		turncost);
    }
}