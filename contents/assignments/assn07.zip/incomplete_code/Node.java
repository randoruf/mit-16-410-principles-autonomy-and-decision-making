package team16410;

import java.util.LinkedList;
/**
 * A node encapsulates a vertex in the search tree.  To maintain the tree
 * structure, each node maintains a pointer to its parent.
 * At each node we store the action required to enter it (from the parent)
 * as well as the distance from the root (for convenience in implementing
 * depth-limited search).
 *
 * for problem set 3 we also require a node to track the cost that has
 * been incurred so far along the path.
 *
 * if you want to avoid loops without using additional memory, 
 * the Node also provides a boolean contains function
 *
 * @author Tom Temple
 *
 **/


public class Node{

    private final State state;
    private final Node parent;
    private final Action action;
    private final int length;
    private final double cost;

    public State getState(){	return state;    }
    public Node getParent(){    return parent;    }
    public Action getAction(){  return action; }
    public int size(){  return length; }
    public double getCost(){   return cost; }

    public Node(State s){
	state = s;
	parent = null;
	action = null;
	length = 0;
	cost = 0;
    }

    public Node(State s,Node n,Action a){
	state = s;
	parent = n;
	action = a;
	length = n.size()+1;
	cost = n.getCost() + a.getCost();
    }

    public Node(Node n,Action a){
	this(a.getPost(),n,a);
    }

    public String toString(){
	if (parent==null)
	    return state.toString();
	return parent.toString() +" then\n" +action.toString();
    }

    /**
     * @return the plan that this node represents.
     **/
    public LinkedList<Action> listifyActions(){
	return listifyActions(this);
    }
    
    /**
     * converts a node into a sequence of actions
     **/
    public static LinkedList<Action> listifyActions(Node n){
	//System.out.println("in listify with\n"+n);
	LinkedList<Action> ret = new LinkedList<Action>();
	Node parent = n.getParent();
	while (parent!=null){
	    ret.add(n.getAction());
	    n = parent;
	    parent = n.getParent();
	}
	return ret;
    }

    /**
     * Determine whether this search node includes state S
     * @param S  the state to check
     * @return true iff S is the state for this node or one of its parents
     **/
    public boolean contains(State S){
	Node thisnode = this;
	while(true){
	    Node _parent = thisnode.getParent();
	    if (thisnode.getState().equals(S))
		return true;
	    if (_parent==null)
		return false;
	    thisnode = _parent;
	}
    }
}
