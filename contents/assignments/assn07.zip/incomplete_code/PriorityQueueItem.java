package team16410;

/**
 * A priority queue item is the pair {<E> object, double key}
 * where "key" is the priority that is used to index "object"
 **/
public class PriorityQueueItem<E> implements Comparable<PriorityQueueItem>{

    public final double key;
    public final E object;
    
    /**
     * @param object             Object of type E to be enqueued
     * @param key    the value with which to enqueue the object
     **/
    public PriorityQueueItem(E object, double key){
	this.key = key;
	this.object = object;
    }

    public int compareTo(PriorityQueueItem other){
	if (this.key > other.key)
	    return 1;
	if (this.key < other.key)
	    return -1;
	return 0;
    }

    public boolean equals(Object other){
	if ((other!=null) && (other instanceof PriorityQueueItem)){
	    PriorityQueueItem otherpq = (PriorityQueueItem)other;
	    return (this.key==otherpq.key && this.object.equals(otherpq.object));
	}
	return false;
    }

    public int hashCode(){
	int obj_code = object.hashCode();
	long bits = Double.doubleToLongBits(key);
	int key_code = (int)(bits ^ (bits >>> 32));
	return key_code + obj_code;
    }
}