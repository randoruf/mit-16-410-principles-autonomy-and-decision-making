package team16410;

import battlecode.common.*;
import static battlecode.common.GameConstants.*;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;
import java.io.*;


/**
 * This class must conform to the regulations imposed by the Battlecode
 * rules.  For instance, we are not allowed to open the map file and so
 * the relevant information is repeated here.
 *
 * This requires that if you wish to modify the map, you must change
 * the map here as well as the xml map file.  If you want to move the 
 * goal location however, you need only change the map here.
 *
 * This class provides the actionsAvailable() method which is responsible
 * for enumerating the possible transitions.
 **/


public class RobotPlayer implements Runnable {

   private final RobotController myRC;

    private boolean active = false;
    private boolean map_complete = false;
    private MapLocation loc;
    private Direction dir;
    private RobotState goal;
    private RobotState start;
    private boolean[][] map;
    private int[][] heights;
    private MapLocation topright;
    private MapLocation bottomleft;
    private LinkedList<Action> actions;
    private BestFirstSearch searcher;

   public RobotPlayer(RobotController rc) {
       myRC = rc;     
       map = cheatMap();
       heights = cheatHeights();
       CostFunction fu;
       CostFunction fg;
       CostFunction fa;
       try{
	   fu = new UniformCostFunction();
	   fg = new GreedyCostFunction(goal);
	   fa = new AdmissibleHeuristicCostFunction(goal);
	   //--------------------------------------------------------------
	   // Change this next line to test the different search algorithms
	   //--------------------------------------------------------------
	   searcher = new BestFirstSearch(fu);
       }catch (CostFunction.NotApplicableException e){
	   System.out.println(e);
       }
   }

   public void run(){
       while(true){
	   try{
	       while(myRC.isMovementActive()) {
		 myRC.yield();
	       }
	       if (actions!=null){
		   if (actions.isEmpty()){
		       System.out.println("Actions is empty");
		       while(true){
			   myRC.yield();
		       }
		   }
		   Action a = actions.removeLast();
		   //System.out.println("doing action "+a);
		   a.doAction();
		   myRC.yield();
	       }else{
		   //actions = searcher.incrementSearch(10000);
		   actions = searcher.search(start,goal);
		   myRC.yield();
	       }
	     /*** end of main loop ***/
	   
	   }catch(Exception e) {
	     System.out.println("caught exception: "+e);
	     e.printStackTrace();
	      while(true) {
		 myRC.yield();
	       }
	   }
       
      }
   }

    /**
     * actionsAvailable is used to generate a set of Actions that can be
     * taken from a given state.  Actions are created here since this allows
     * them to be created with a referrence to the RobotController and 
     * thereby can implement the doAction() functor. For more, see the
     * definition of Action
     * @param state  the state from which we would like to know
     *        the available actions
     * @return the available actions.
     *
     * As a practical matter, I am not including directions like SOUTH_EAST
     * or the backward() action at the moment since the search is slow enough
     * as it is.
     */
    public Set<Action> actionsAvailable(RobotState state){
	Set<Action> actions = new HashSet<Action>();
	for(Direction d : Direction.values())
	    if (!d.equals(state.getDirection()))
		if (d.equals(Direction.SOUTH) ||
		    d.equals(Direction.EAST) ||
		    d.equals(Direction.NORTH) ||
		    d.equals(Direction.WEST))
		    actions.add(new TurnAction(state,d,myRC,
			 Constants.turnCost(state.getDirection(),d)));
	if (canMove(state.getLocation().add(state.getDirection())))
	    actions.add(new ForwardAction(state,myRC,
					  forwardCost(state)));
	//if (canMove(state.getLocation().subtract(state.getDirection())))
	//    actions.add(new BackwardAction(state,myRC));
	return actions;
    }

    /**
     * a helper method to actionsAvailable() that queries the map
     * and decides if move actions are legal.
     * Note that since we aren't _actually_ at location _loc (nor have
     * we ever seen it), we cannot
     * use the RobotController methods that do the same thing.
     */
    private boolean canMove(MapLocation _loc){
	int x = _loc.getX();
	int y = _loc.getY();
	//System.out.println("map["+x+"]["+y+"]="+map[y][x]);
	if (x<0 || y<0 ||x>=map[0].length || y>=map.length)
	    return false;
	return (map[y][x]);
    }

    /**
     * The cost to move forward one step from the given state
     * @param S
     * @return the cost to move forward one step from S
     **/
    private double forwardCost(RobotState S){
    	MapLocation end = S.getLocation().add(S.getDirection());
	//System.out.println("forwardCost("+S+")");
	return Constants.forwardCost(heights[end.getY()][end.getX()]);
    }


    /**
     * We have to hard code the map if we are going to allow our algorithms
     * to have prior knowledge.
     * The following ascii-art is the map that will be used by the
     * search algorithm.  If this is going to work, it must match the
     * xml file used by Battlecode.
     * the goal 'G' may be moved without modifying the xml
     * any other changes must be mirrored.
     * (Looks good at 80 characters wide)
     **/
    private  boolean[][] cheatMap(){
	String wholemap= ""+
	    "##############################\n"+
	    "#A                           #\n"+
	    "#  ##                    #   #\n"+
	    "# #####                 ###  #\n"+
	    "# ######      ##       ####  #\n"+
	    "#  ##       ######   ######  #\n"+
	    "#      #    ######   ######  #\n"+
	    "#     ##    ######   ####    #\n"+	 
	    "#     ###    #####    ##     #\n"+
	    "#      ##     ####           #\n"+
	    "#  ##  ###    #####          #\n"+	    
	    "# ###   ###    ####          #\n"+
	    "#  ###      #######          #\n"+
	    "#  ####     ######           #\n"+
	    "#            #####           #\n"+
	    "#              ###           #\n"+
	    "#               ###          #\n"+	 
	    "#               ###    #     #\n"+	  
	    "#               ##   #####   #\n"+	
	    "#              ###   ######  #\n"+    
	    "#             ####   ######  #\n"+   
	    "#            ####    ### ##  #\n"+     
	    "#           ####     ### ##  #\n"+  
	    "#           ### G   ######## #\n"+  
	    "#           ###     ######## #\n"+
	    "#           ###   ##### #### #\n"+
	    "#           ###  ######  ##  #\n"+
	    "#                 ###        #\n"+
	    "#                           B#\n"+
	    "##############################";
	String[] lines = wholemap.split("\n");
	int height = 30;
	int width = 30;
	boolean[][] _map = new boolean[height][width];
	for (int i=0;i<height;i++){
	    String line = lines[i].trim();
	    //System.out.println("line="+line);
	    for (int j=0;j<width;j++){
		    switch (line.charAt(j)){
		    case ' ': _map[i][j] = true; break;
		    case '#': _map[i][j] = false; break;
		    case 'G': 
			_map[i][j] = true;
			goal = new RobotState(this,new MapLocation(j,i),Direction.SOUTH);
			break;
		    case 'A': 
			_map[i][j] = true;
			start = new RobotState(this,new MapLocation(j,i),Direction.NORTH);
			break;
		    default:
			_map[i][j] = false; break;
		    
		}
	    }
	}
	return _map;
    }


    private  int[][] cheatHeights(){
	// The following ascii-art is the map that will be used by the
	// search algorithm.  If this is going to work, it must match the     
	// xml file used by Battlecode.
	// the goal 'G' may be moved without modifying the xml
	// any other changes must be mirrored.
	// (Looks good at 48 characters wide)
	String wholemap= ""+
	    "140132322213310211113420200310\n"+
	    "344414103341000304130203124240\n"+
	    "300313344244122140214420442212\n"+
	    "033330421132241200011233032310\n"+
	    "224010233044404143444233002234\n"+
	    "012400412043031300004341042111\n"+
	    "003024102320422431202240432112\n"+
	    "300221341212234310042224141441\n"+
	    "014040141214121001230321104301\n"+
	    "401043031330302124402212023212\n"+
	    "200113213222222143231041301230\n"+
	    "340034310002112243141224104341\n"+
	    "041041400324020424331232303310\n"+
	    "230110022143333230344310112434\n"+
	    "130340340303213301012032303222\n"+
	    "001200313241221344443114003242\n"+
	    "302241240423113140430340013404\n"+
	    "240311014044342222241431002121\n"+
	    "143022022332410042211044304140\n"+
	    "232332104013224313030321211424\n"+
	    "311101321210111224311342410031\n"+
	    "441323433231314030223241442041\n"+
	    "141402230310234423240133340044\n"+
	    "113140003404200032431410214010\n"+
	    "304323211211432410223334402012\n"+
	    "420003434242101411112234414114\n"+
	    "201040240424042413412033220102\n"+
	    "214013133103100324014242113431\n"+
	    "040343431034040043102232213123\n"+
	    "000204212103142022302144102430";
	String[] lines = wholemap.split("\n");
	int height = 30;
	int width = 30;
	int[][] _map = new int[height][width];
	for (int i=0;i<height;i++){
	    String line = lines[i].trim();
	    //System.out.println("line="+line);
	    for (int j=0;j<width;j++){
		_map[i][j] = Integer.parseInt(""+(line.charAt(j)));
	    }
	}
    
	return _map;
    }

}
