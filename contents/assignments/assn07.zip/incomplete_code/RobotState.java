package team16410;

import java.util.Set;
import battlecode.common.*;

/**
 * A Robot State consists of a location and a direction that corresponds
 * with a state in the Battlecode simulation
 *
 * provide actionsAvailable, by maintaining a referrence to the RobotPlayer
 * that knows the map.
 *
 **/


public final class RobotState extends State{

    private final RobotPlayer myRP;
    private final MapLocation location;
    private final Direction direction;

    public RobotState(RobotPlayer rp, MapLocation loc, Direction dir){
	myRP = rp;
	location = loc;
	direction = dir;
    }

    public int hashCode(){
	return(location.hashCode()*direction.hashCode());
    }

    public Direction getDirection(){
	return direction;
    }

    public MapLocation getLocation(){
	return location;
    }

    public RobotPlayer getRP(){
	return myRP;
    }

    /**
     * Enumerates the available actions by asking the Robot Player
     * @return all of the actions that can be taken from this state
     **/
    public Set<Action> actionsAvailable(){
	return myRP.actionsAvailable(this);
    }

    public boolean equals(Object other){
	if (!(other instanceof RobotState))
	    return false;
	if (location.equals(((RobotState)other).getLocation()) &&
	    direction.equals(((RobotState)other).getDirection()))
	    return true;
	return false;
    }

    public String toString(){
	return "in "+location+" facing "+direction;
    }

  					      
}
	
		