package team16410;


/**
   This is a class to encapsulate the state in a transition system
   A state should be able to enumerate the available actions as well
   as provide the outcomes of those actions.  

   It is also important that a state implement "equals" and "hashCode"
   correctly.
   
   A state is immutable.
**/


import java.util.Set;

public abstract class State{

    public abstract Set<Action> actionsAvailable();

    //public abstract boolean equals(State other);
    public abstract int hashCode();
}