package team16410;
import battlecode.common.*;

/**
 * This class provides the doAction function that turns the robot
 */
public final class TurnAction extends Action{
    RobotController rc;
    Direction d;
    public TurnAction(RobotState _pre,Direction _d, 
		      RobotController _rc, double _cost){
	super(_pre, new RobotState(_pre.getRP(),_pre.getLocation(),_d),
	      "turn "+_d,_cost);
	rc = _rc;
	d = _d;
    }
    
    /**
     * Turn the robot to the new direction
     * @throws GameActionException if this move is illegal
     **/
    public void doAction() throws GameActionException{
	rc.setDirection(d);
    }
}
