import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.List;

import pddl4j.PDDLObject;
import pddl4j.Parser;
import pddl4j.exp.*;
import pddl4j.exp.AndExp;
import pddl4j.exp.OrExp;
import pddl4j.exp.AtomicFormula;
import pddl4j.exp.Exp;
import pddl4j.exp.ExpID;
import pddl4j.exp.NotExp;
import pddl4j.exp.term.Term;
import pddl4j.exp.action.Action;
import pddl4j.exp.action.ActionDef;


public class pddlparser {
		
	public static void main (String[] args) {
		
		if (args.length != 2){
			System.out.println("Not enough arguments");
			System.exit(0);
		}	
		
		// Set parser options
		Properties options = new Properties();
		
        // Create the parser objects and read in the files
		Parser parser = new Parser (options);
		PDDLObject domain = null;
		PDDLObject problem = null;
		try{
			domain = parser.parse (new File(args[0]));
		}
		catch(IOException e){
			System.out.println ("File error: " + e.getMessage());
			System.exit(0);
		}
		try{
			problem = parser.parse (new File(args[1]));
		}
		catch(IOException e){
			System.out.println ("File error: " + e.getMessage());
			System.exit(0);
		}
		PDDLObject pb = null;
		if (domain != null && problem != null) {
			pb = parser.link(domain, problem);
			System.out.println("Input PDDL files parsed successfully");
		}
		else {
			System.out.println("Error parsing the PDDL files");
			System.exit(0);
		}
		
		
		// List all the predicates
		Iterator<AtomicFormula> atomicFormulaList = pb.predicatesIterator();
		while (atomicFormulaList.hasNext()) {
			System.out.println("\nNEW PREDICATE:");
			AtomicFormula atomicFormula= atomicFormulaList.next();
			// Print the predicate
			System.out.println("Predicate : " + atomicFormula.getPredicate());
			Iterator<Term> termList = atomicFormula.iterator();
			while(termList.hasNext()){
				Term term = termList.next();
				System.out.println("Variable  : " + term.getImage());
			}
		}
		
		// List all the actions
		Iterator<ActionDef> actionDefList = pb.actionsIterator();
		while (actionDefList.hasNext()){
			
			System.out.println("\n\nNEW ACTION:");
			
			// Print action as a string
			ActionDef actionDef = actionDefList.next();
			System.out.println(actionDef.toString());
			
			
			// Printout the parameters for this action
			System.out.println("\nParameters of this action:");
			Set<Term> parametersSet = actionDef.getParameters();
			Iterator<Term> parameterIt = parametersSet.iterator();
			while (parameterIt.hasNext()){
				Term parameter = parameterIt.next();
				System.out.println("parameter : " + parameter.toString());
			}
			
			// Get action via cast
			Action action = (Action) actionDef;
			
			// Get the precondition in conjunctive normal form
			Exp precon = action.getPrecondition().toConjunctiveNormalForm();
			// Print out the precondition 
			System.out.println("\nPrecondition   : " + precon.toString());
			System.out.println("Parsing the precondition...");
			parseExpression(precon);
			
			// Get the effect in conjunctive normal form
			Exp effect = action.getEffect().toConjunctiveNormalForm();
			// Print out the effect
			System.out.println("\nEffect         : " + effect.toString());
			System.out.println("Parsing the effect...");
			parseExpression(effect);
		}
		
		// Get the initial state of the problem
		System.out.println("\nINITAL STATE:");
		List<InitEl> initElList = pb.getInit();
		for (InitEl initEl : initElList){
			System.out.println("Initial literal : " + initEl.toString());
		}
		
		
		// Get the goal expression of the problem
		System.out.println("\nGOAL STATE:");
		Exp goalExp = pb.getGoal();
		System.out.println("Goal expression : " + goalExp);
		System.out.println("Parsing the goal...");
		parseExpression(goalExp);
		
		
		System.out.println("\nPDDL4J example program completed successfully");		
	}
	
	public static void parseExpression (Exp exp) {
		
		if (exp.getExpID().equals(ExpID.ATOMIC_FORMULA)) {   // Check whether the expression is an atomic formula
			AtomicFormula atomicFormula = (AtomicFormula) exp;
			System.out.println("Atomic formula : " + atomicFormula.toString()); // Print out the atmoic formula string
			System.out.println("  name     : " + atomicFormula.getPredicate()); // Print out the name of the predicate
			System.out.println("  num vars : " + atomicFormula.getArity());     // Print out the number of variables that the predicate accepts
		}
		
		else if (exp.getExpID().equals(ExpID.AND)) { 	// Check whether the expression is a conjunction of other expressions 
			AndExp andExp = (AndExp) exp;
			System.out.println("And expression : " + exp.toString());  	// Print out the expression string
			for (Exp childExp : andExp) {								// Recurse to examine each of the children expressions
				parseExpression (childExp);
			}
		}
		
		else if (exp.getExpID().equals(ExpID.OR)) {		// Check whether the expression is a disjunction of other expressions
			OrExp orExp = (OrExp) exp;
			System.out.println("And expression : " + exp.toString());  	// Print out the expression string
			for (Exp childExp : orExp) {								// Recurse to examine each of the children expressions
				parseExpression (childExp);
			}
		}
	
		else if (exp.getExpID().equals(ExpID.NOT)){		// Check whether the expression is a negation of an other expression
			NotExp notExp = (NotExp) exp;
			System.out.println("Not expression : " + exp.toString());  	// Print out the expression string
			parseExpression (notExp.getExp());							// Recurse to examine the child expression 
		}
		
		else {
			System.out.println("Can not handle the operator type in : " + exp.toString());
			System.exit(0);
		}		
	}
}

