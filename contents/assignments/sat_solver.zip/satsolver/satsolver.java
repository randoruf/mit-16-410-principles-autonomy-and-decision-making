import org.sat4j.core.VecInt;
import org.sat4j.minisat.SolverFactory;
import org.sat4j.specs.*;

public class satsolver {
	public static void main (String args[]){
		final int MAX_VAR = 10; 
		final int NUM_CLAUSES = 1;
		
		System.out.println("SAT4J example code\n");
		
		// Initialize the SAT solver
		ISolver solver = SolverFactory.newDefault ();
		
		
		solver.newVar(MAX_VAR);   // Set maximum number of variables that may arise
		solver.setExpectedNumberOfClauses(NUM_CLAUSES); // Set maximum number of clauses that may arise
		
		
		// Initialize the clauses and add them to the problem
		// The clauses are conjuncts of a conjunctive normal form
		int [] clause;
		try {
			// Add a new clause : (p_1 or (not p_3) or p_7)
			clause = new int [3];  
			clause[0] = 1;
			clause[1] = -3;
			clause[2] = 7;
			solver.addClause(new VecInt(clause));
			
			// Add a new clause : ((not p_1) or p_3 or p_7)
			clause = new int [3];
			clause[0] = -1;
			clause[1] = 3;
			clause[2] = 7;
			solver.addClause(new VecInt(clause));
			
			// Add a new clause : (p_1 or p_3 or p_7
			clause = new int [3];
			clause[0] = 1;
			clause[1] = 3;
			clause[2] = 7;
			solver.addClause(new VecInt(clause));
		}
		catch (ContradictionException e){   // You need to handle the contradiction exception
			System.out.println("Contradiction Exception : " + e.getMessage());
			System.exit(0);
		}
		
		// Set solver parameters
		solver.setTimeout(10); // Solver timeout in seconds 
		
		
		// Solve the satisfiability problem
		IProblem problem = solver;
		try{
			if (problem.isSatisfiable()) {   // If the problem is satisfiable, then print the results
				System.out.println("Clauses can be satisfied");
				System.out.println("Number of variables used   : " + problem.nVars());
				System.out.println("Number of constraints used : " + problem.nConstraints());
				int [] model = problem.model();
				for (int i = 0; i < model.length; i++) {
					System.out.println("var[" + i + "] = "  + model[i]);
				}
			}
			else {  // If the problem is not satisfiable, then indicate so
				System.out.println("This set of clauses is not satisfiable");
			}
		}
		catch (TimeoutException e){ // You need to handle the timeout exception, which is thrown if 
									// the solver can not find a solution within the given time bound
			System.out.println("Solver timed out : " + e.getMessage());
			System.exit(0);
		}
		
		System.out.println("\nSAT4J example program completed successfully");
	}
}
