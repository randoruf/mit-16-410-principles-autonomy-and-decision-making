/**
 * This Graph class implements a directed graph.
 * 
 * @author		
 */
import java.util.Set;
import java.util.HashSet;

public class Graph {
	/**
	 * An adjacency matrix (2-D boolean array) is used to
	 * represent a set of edges.
	 */
	protected boolean m_edges[][];
	
	/**
	 * Default constructor. Assumes at most 100 vertices.
	 */
	public Graph()
	{
		int vertexCount = 100;
		m_edges = new boolean[vertexCount][vertexCount];
	}
	
	/**
	 * Constructor. This constructor can be used to specify
	 * the desired number of vertices.
	 * @param vertexCount		Number of desired vertices.
	 */
	public Graph(int vertexCount)
	{
		m_edges = new boolean[vertexCount][vertexCount];
	}
	
	/**
	 * Add an edge from the <code>from</code> vertex to the
	 * <code>to</code> vertex.
	 * @param from		Source vertex of the edge to be added.
	 * @param to		Target vertex of the edge to be added.
	 */
	public void addEdge(int from, int to)
	{
		// Check to make sure that both <code>from</code>
		// and <code>to</code> vertices are within the allowed
		// range of vertex indices.
		if (from < m_edges.length & to < m_edges.length)
		{
			// Add an edge from <code>from</code> vertex to
			// the <code>to</code> vertex.
			m_edges[from][to] = true;
		}
	}
	
	/**
	 * Delete an edge from the <code>from</code> vertex to the
	 * <code>to</code> vertex.
	 * @param from		Source vertex of the edge to be deleted.
	 * @param to		Target vertex of the edge to be deleted.
	 */
	public void deleteEdge(int from, int to)
	{
		// Check to make sure that both <code>from</code>
		// and <code>to</code> vertices are within the allowed
		// range of vertex indices.
		if (from < m_edges.length & to < m_edges.length)
		{
			// Delete the edge from <code>from</code> vertex to
			// the <code>to</code> vertex.
			m_edges[from][to] = false;
		}
	}
	
	/**
	 * Checks if an edge exists in this graph.
	 * @param from		Source vertex of an edge
	 * @param to		Target vertex of an edge
	 * @return			Returns <code>true</code> if the
	 * 					edge exists, otherwise returns
	 * 					<code>false</code>.
	 */
	public boolean isConnected(int from, int to)
	{
		if (from < m_edges.length & to < m_edges.length)
		{
			return (m_edges[from][to]);
		}
		return false;
	}
	
	/**
	 * Find all adjacent vertices.
	 * @param from		Source vertex
	 * @return			A set of vertices adjacent to the
	 * 					vertex.
	 */
	public Set<Integer> getAdjacentVertices(int from)
	{
		HashSet<Integer> reachableVertices = new HashSet<Integer>();
		for (int i = 0; i < m_edges[from].length; i++)
		{
			if (isConnected(from,i))
			{
				reachableVertices.add(i);
			}
		}
		return reachableVertices;
	}
}
