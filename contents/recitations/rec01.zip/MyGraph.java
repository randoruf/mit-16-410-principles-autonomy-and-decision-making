import java.util.Set;

public class MyGraph {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int vertexCount = 7;
		Graph graph;
		int vertexIndex;
		Set<Integer> adjacentVertices;
		
		graph = new Graph(vertexCount);
		graph.addEdge(0, 1);
		graph.addEdge(0, 2);
		graph.addEdge(1, 3);
		graph.addEdge(1, 4);
		graph.addEdge(2, 5);
		graph.addEdge(2, 6);
		
		vertexIndex = 2;
		adjacentVertices = graph.getAdjacentVertices(vertexIndex);
		System.out.println("Vertices Adjacent to " + vertexIndex + " are: " + adjacentVertices);

		graph = new UndirectedGraph(vertexCount);
		graph.addEdge(0, 1);
		graph.addEdge(0, 2);
		graph.addEdge(1, 3);
		graph.addEdge(1, 4);
		graph.addEdge(2, 5);
		graph.addEdge(2, 6);
		
		vertexIndex = 2;
		adjacentVertices = graph.getAdjacentVertices(vertexIndex);
		System.out.println("Vertices Adjacent to " + vertexIndex + " are: " + adjacentVertices);
	}
}
