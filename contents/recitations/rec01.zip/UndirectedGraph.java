public class UndirectedGraph extends Graph
{
	public UndirectedGraph(int vertexCount)
	{
		super(vertexCount);
	}
	
	public void addEdge(int from, int to)
	{
		if (from < m_edges.length & to < m_edges.length)
		{
			m_edges[from][to] = true;
			m_edges[to][from] = true;
		}
	}
	
	public void deleteEdge(int from, int to)
	{
		if (from < m_edges.length & to < m_edges.length)
		{
			m_edges[from][to] = false;
			m_edges[to][from] = false;
		}
	}
}
